# PythonCourse
Is a course of python from the channel pildorasinformaticas on youtube,
i translated an extract of the course into English.

I hope you enjoy.
