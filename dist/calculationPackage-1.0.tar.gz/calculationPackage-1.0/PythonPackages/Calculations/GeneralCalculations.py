def sum(op1,op2):
    print("the sum is: ",(op1+op2))
def abstraction(op1,op2):
    print("the abstraction result is: ",op1-op2)
def multiply(op1,op2):
    print("the multiply result is: ",op1*op2)
def divide(op1,op2):
    print("the result of the division is: ",op1/op2)



