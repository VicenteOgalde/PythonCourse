from Calculations.GeneralCalculations import *

sum(10,10)
divide(9,3)