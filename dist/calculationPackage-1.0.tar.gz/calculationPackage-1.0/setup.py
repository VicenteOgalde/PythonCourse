from setuptools import setup

setup(
    name="calculationPackage",
    version="1.0",
    description="Package of basic calculations",
    author="Vicente Ogalde",
    packages=["PythonPackages","PythonPackages.Calculations"]
)